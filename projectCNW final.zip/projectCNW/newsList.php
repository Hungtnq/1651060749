<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('admin-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                        <h4>Danh sách bài viết</h4>
                        <?php 
                            include('mysql-connect.php');
                            $sql = "select baiviet.mabv,baiviet.tieude,baiviet.tomtat,quantri.tenqt as tacgia from baiviet,quantri where baiviet.maqt = quantri.maqt";
                            $result = mysqli_query($conn,$sql);
                            if (mysqli_num_rows($result) > 0) {
                                echo"<table>";
                                echo"<tr>";
                                echo"<th>Mã bài viết</th>";
                                echo"<th>Tiêu đề</th>";
                                echo"<th>Tóm tắt</th>";
                                echo"<th>Tác giả</th>";
                                echo"<th>Sửa</th>";
                                echo"<th>Xóa</th>";
                                echo"</tr>";
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo"<tr>";
                                    echo"<td>".$row['mabv']."</td>";
                                    echo"<td>".$row['tieude']."</td>";
                                    echo"<td>".$row['tomtat']."</td>";
                                    echo"<td>".$row['tacgia']."</td>";
                                    $mabv = $row['mabv'];
                                    echo"<td><button onclick=\"window.location.href='updNews.php?bv=".$mabv."'\">Sửa</button></td>";
                                    echo"<td><button data-toggle='modal' data-target='#delNews'>Xóa</button></td>";
                                    echo"</tr>";
                                }
                                echo"</table>";    
                            }
                            include('mysql-close.php');
                        ?>
                        <br>
                        <button onclick="window.location.href='addNews.php'">Thêm bài viết</button>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="delNews" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Xóa bài viết</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Bạn có chắc muốn xóa bài viết ?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Không</button>
                        <?php echo"<button type='button' onclick=\"window.location.href='delNews.php?bv=".$mabv."'\" class='btn btn-primary'>Xóa</button>"; ?>
                    </div>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>