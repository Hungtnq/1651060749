<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 class">
                        <?php 
                            if(!empty($_GET)){
                                $lop = $_GET['lop'];
                                $sv = $_GET['sv'];
                                include('mysql-connect.php');
                                $sql1 = "select tenlop from lophoc where malop=".$lop;
                                $sql2 = "select tensv from sinhvien where masv=".$sv;
                                echo"<h4>Lớp: ".mysqli_fetch_assoc(mysqli_query($conn,$sql1))['tenlop']."</h4>";
                                echo"<h4>Sinh viên: ".mysqli_fetch_assoc(mysqli_query($conn,$sql2))['tensv']."</h4>";
                                include('mysql-close.php');
                            }
                            else{
                                echo"Lỗi";
                            }
                            if(!empty($_POST)){
                                include('mysql-connect.php');
                                if(!empty($_POST['diemqt']) && empty($_POST['diemthi'])){
                                    $diemqt = $_POST['diemqt'];
                                    $sql = "UPDATE diem set diemqt = ".$diemqt." where malop=".$lop." and masv=".$sv;
                                }
                                else if(!empty($_POST['diemthi']) && empty($_POST['diemqt'])){
                                    $diemthi = $_POST['diemthi'];
                                    $sql = "UPDATE diem set diemthi = ".$diemthi." where malop=".$lop." and masv=".$sv;
                                }
                                else if(!empty($_POST['diemqt']) && !empty($_POST['diemthi'])){
                                    $diemqt = $_POST['diemqt'];
                                    $diemthi = $_POST['diemthi'];
                                    $sql = "UPDATE diem set diemqt = ".$diemqt.", diemthi=".$diemthi." where malop=".$lop." and masv=".$sv;
                                }
                                $result = mysqli_query($conn,$sql);
                                include('mysql-close.php');
                            }
                            echo"<form action=\"updPoint.php?id=".$_GET['id']."&lop=".$lop."&sv=".$sv."\" method='post'>";
                            echo"<div class='row'>";
                            echo"<label class='col-2' for=''>Điểm quá trình:</label>";
                            echo"<input class='col-5' type='text' name='diemqt' id=''>";
                            echo"</div>";
                            echo"<br>";
                            echo"<div class='row'>";
                            echo"<label class='col-2' for=''>Điểm thi:</label>";
                            echo"<input class='col-5' type='text' name='diemthi' id=''>";
                            echo"</div>";
                            echo"<br>";
                            echo"<input type='submit' value='Sửa'>";
                            echo"</form>";
                        ?>
                        
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>