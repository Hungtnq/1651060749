<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('mng-nav.php'); ?> 
                    </div>
                    <div class="col-9 class-list">
                        <h4>Sửa lớp: </h4>
                        <form action="updateClass.php" method='post'>
                            <label class="col-2" for="">Tên lớp</label>
                            <input class="col-5" type="text" name="tenlop" id="" >
                            <br>
                            <label class="col-2" for="">Trọng số</label>
                            <input class="col-5" type="text" name="ts" id="" >
                            <br>
                            <label class="col-2" for="">Môn học</label>
                            <?php 
                                include('mysql-connect.php');
                                echo"<select name='mh' id='' >";
                                echo"<option value=''></option>";
                                $sql_mh = "select mamon,tenmon from monhoc";
                                $result_mh = mysqli_query($conn,$sql_mh);
                                while($row_mh = mysqli_fetch_assoc($result_mh)){
                                    echo"<option value='".$row_mh['mamon']."'>".$row_mh['tenmon']."</option>";
                                }
                                echo"</select>";
                                include('mysql-close.php');
                            ?>
                            <br>
                            <label class="col-2" for="">Giảng viên</label>
                            <?php 
                                include('mysql-connect.php');
                                echo"<select name='gv' id='' >";
                                echo"<option value=''></option>";
                                $sql_mh = "select magv,tengv from giangvien";
                                $result_mh = mysqli_query($conn,$sql_mh);
                                while($row_mh = mysqli_fetch_assoc($result_mh)){
                                    echo"<option value='".$row_mh['magv']."'>".$row_mh['tengv']."</option>";
                                }
                                echo"</select>";
                                include('mysql-close.php');
                            ?>
                            <br>
                            <label class="col-2" for="">Năm học</label>
                            <select name="nam" id="" >
                                <option value=""></option>
                                <option value="2019_2020">2019-2020</option>
                                <option value="2019_2020">2019-2020</option>
                                <option value="2019_2020">2019-2020</option>
                                <option value="2019_2020">2019-2020</option>
                                <option value="2019_2020">2019-2020</option>
                                <option value="2019_2020">2019-2020</option>
                                <option value="2019_2020">2019-2020</option>
                            </select>
                            <br>
                            <label class="col-2" for="">Kỳ học</label>
                            <select name="ky" id="" >
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="song song">song song</option>
                                <option value="he">hè</option>
                            </select>
                            <br>
                            <label class="col-2" for="">Giai đoạn</label>
                            <select name="gd" id="" >
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                            <br>
                            <input type="submit" class="addClass" value="Thêm lớp">
                        </form>
                        <?php 
                            if(!empty($_GET)){
                                $lop = $_GET['lop'];
                            }
                        ?>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php 
    if(!empty($_POST)){
        include('mysql-connect.php');
        if($_POST['ky'] != "song song" && $_POST['ky'] != "he"){ 
            $sql = "update lophoc set tenlop = '".$_POST['tenlop']."', trongso=".$_POST['ts'].", Namhoc = '".$_POST['nam']."', Kyhoc = '".$_POST['ky']."', Giaidoan='".$_POST['gd']."', mamon=".$_POST['mh'].", magv=".$_POST['gv']." 
            where malop = ".$_GET['lop'].")";
        }
        else {
            $sql = "update lophoc set tenlop = '".$_POST['tenlop']."', trongso=".$_POST['ts'].", Namhoc = '".$_POST['nam']."', Kyhoc = '".$_POST['ky']."', mamon=".$_POST['mh'].", magv=".$_POST['gv']." 
            where malop = ".$_GET['lop'].")";
        }
        mysqli_query($conn,$sql);
        include('mysql-close.php');
    }
?>