<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('admin-nav.php'); ?>
                    </div>
                    <div class="col-9">
                        <h4>Thêm tài khoản: </h4>
                        <form action="addAcc.php" method="post">
                            <label class="col-2" for="">Tài khoản</label>
                            <input type="text" name="tentk" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Mật khẩu</label>
                            <input type="text" name="matkhau" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Email</label>
                            <input type="text" name="email" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Mã</label>
                            <input type="text" name="ma" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Họ và tên</label>
                            <input type="text" name="HvT" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Quê quán</label>
                            <input type="text" name="qq" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Ngày sinh</label>
                            <input type="text" name="ns" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Giới tính</label>
                            <select name="gt" id="">
                                <option value=""></option>
                                <option value="nam">Nam</option>
                                <option value="nu">Nữ</option>
                            </select>
                            <br>
                            <label class="col-2" for="">Số CMTND</label>
                            <input type="text" name="cmtnd" class="col-5" id="" required>
                            <br>
                            <label class="col-2" for="">Chức vụ</label>
                            <select name="cv" id="" required>
                                <option value=""></option>
                                <option value="sinhvien">sinh viên</option>
                                <option value="giangvien">giảng viên</option>
                                <option value="quanly">quản lý</option>
                                <option value="quantri">quản trị</option>
                            </select>
                            <br>
                            <label class="col-2" for="">Ngành</label>
                            <?php 
                                include('mysql-connect.php');
                                echo"<select name='ng' id='' required>";
                                echo"<option value=''></option>";
                                $sql_ng = "select tenNg from nganh";
                                $result_ng = mysqli_query($conn,$sql_ng);
                                while($row_ng = mysqli_fetch_assoc($result_ng)){
                                    echo"<option value='".$row_ng['tenNg']."'>".$row_ng['tenNg']."</option>";
                                }
                                echo"</select>";
                                include('mysql-close.php');
                            ?>
                            <br>
                            <br>
                            <input type="submit" value="Thêm tài khoản">
                        </form>
                    </div>
                </div>
            </div>
            <?php 
                if(!empty($_POST)){
                    include('mysql-connect.php');
                    $time = time();       
                    $chucvu = $_POST['cv'];
                    $matkhau = md5($_POST['matkhau'] . $time);
                    $sql = "insert into taikhoan(tenTK,matkhau,email,chucvu,thoigian,trangthai) values('".$_POST['tentk']."','".$matkhau."','".$_POST['email']."','".$chucvu."',".$time.",1)";
                    mysqli_query($conn,$sql);
                    $sql1 = "select id from taikhoan where tenTK = '".$_POST['tentk']."' and thoigian = ".$time;
                    $result1 = mysqli_query($conn,$sql1);
                    if(mysqli_num_rows($result1) == 1){
                        $row = mysqli_fetch_assoc($result1);
                        $ID = $row['id'];
                        if($chucvu == 'sinhvien'){
                            $sql2 = "select maNg from nganh where tenNg = '".$_POST['ng']."'";
                            $result2 = mysqli_query($conn,$sql2);
                            if(mysqli_num_rows($result2) == 1){
                                $row2 = mysqli_fetch_assoc($result2);
                                $maNg = $row2['maNg'];
                                $sql3 = "insert into sinhvien values(".$_POST['ma'].",'".$_POST['HvT']."','".$_POST['qq']."','".$_POST['ns']."','".$_POST['gt']."',".$_POST['cmtnd'].",".$maNg.",".$ID.")";
                                mysqli_query($conn,$sql3);
                            }
                        }
                        if($chucvu == 'giangvien'){
                            $sql2 = "select maNg from nganh where tenNg = '".$_POST['ng']."'";
                            $result2 = mysqli_query($conn,$sql2);
                            if(mysqli_num_rows($result2) == 1){
                                $row2 = mysqli_fetch_assoc($result2);
                                $maNg = $row2['maNg'];
                                $sql3 = "insert into giangvien values(".$_POST['ma'].",'".$_POST['HvT']."','".$_POST['qq']."','".$_POST['ns']."','".$_POST['gt']."',".$_POST['cmtnd'].",".$maNg.",".$ID.")";
                                mysqli_query($conn,$sql3);
                            }
                        }
                        if($chucvu == 'quanly'){
                            $sql3 = "insert into quanly values(".$_POST['ma'].",'".$_POST['HvT']."','".$_POST['qq']."','".$_POST['ns']."','".$_POST['gt']."',".$_POST['cmtnd'].",".$ID.")";
                            mysqli_query($conn,$sql3);
                        }
                        if($chucvu == 'quantri'){
                            $sql3 = "insert into quantri values(".$_POST['ma'].",'".$_POST['HvT']."','".$_POST['qq']."','".$_POST['ns']."','".$_POST['gt']."',".$_POST['cmtnd'].",".$ID.")";
                            mysqli_query($conn,$sql3);
                        }
                    }
                    include('mysql-close.php');
                }
            ?>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

