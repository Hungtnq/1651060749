<h3 style="padding-bottom:20px">Danh mục chính</h3>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                            <?php
                                echo"<a class='nav-link' href='classList.php?id=".$_GET['id']."'>Danh sách lớp giảng dạy</a>";
                            ?>
                            </li>
                            <li class="nav-item">
                                <?php 
                                    $link = "changePass.php?id=".$_SESSION['user_id'];
                                    echo"<a class='nav-link' href=".$link.">Đổi mật khẩu</a>" 
                                ?>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 3</a>
                                
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 4</a>
                                
                            </li>
                        </ul>