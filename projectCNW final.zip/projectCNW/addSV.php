        <header>
            <?php
            include('header.php');

            ?>
            </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                        <form action="">
                            <label for="">Tên sinh viên</label>
                            <input type="text">
                            <br>
                            <label for="">Giới tính</label>
                            <input type="text">
                            <br>
                            <label for="">Quê quán</label>
                            <input type="text">
                            <br>
                            <label for="">Ngày sinh</label>
                            <input type="text">
                            <br>
                            <label for="">Số CMTND</label>
                            <input type="text">
                            <br>
                            <label for="">Khoa</label>
                            <select name="" id="">
                                <option value=""></option>
                                <option value=""></option>
                                <option value=""></option>
                            </select>
                            <br>
                            <label for="">Ngành</label>
                            <select name="" id="">
                                <option value=""></option>
                                <option value=""></option>
                                <option value=""></option>
                            </select>
                            <br>
                        </form>
                    </div>
                </div>
            </div>
        </main>