<?php 
    if(!empty($_POST)){
        include('mysql-connect.php');
        if(!empty($_POST['masv'])){
            $masv = $_POST['masv'];
            if(!empty($_POST['tenmon'])){
                $tenmon = $_POST['tenmon'];
                if(!empty($_POST['nam'])){
                    $namhoc = $_POST['nam'];
                    if(!empty($_POST['ky'])){
                        $kyhoc = $_POST['ky'];
                        if(!empty($_POST['gd'])){
                            $gd = $_POST['gd'];
                            $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                            and diem.masv =".$masv." and monhoc.tenmon=".$tenmon." and lophoc.Namhoc=".$namhoc." and lophoc.Kyhoc=".$kyhoc." and lophoc.Giaidoan=".$gd;
                        }
                        else{
                            $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                            and diem.masv =".$masv." and monhoc.tenmon=".$tenmon." and lophoc.Namhoc=".$namhoc." and lophoc.Kyhoc=".$kyhoc;
                        }
                    }
                    else{
                        $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                            and diem.masv =".$masv." and monhoc.tenmon=".$tenmon." and lophoc.Namhoc=".$namhoc;
                    }
                }
                else{
                    $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                            and diem.masv =".$masv." and monhoc.tenmon=".$tenmon;
                }
            }
            else{
                $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                            and diem.masv =".$masv;
            }
        }
        else{
            if(!empty($_POST['CMTND'])){
                $cmtnd = $_POST['CMTND'];
                if(!empty($_POST['tenmon'])){
                    $tenmon = $_POST['tenmon'];
                    if(!empty($_POST['nam'])){
                        $namhoc = $_POST['nam'];
                        if(!empty($_POST['ky'])){
                            $kyhoc = $_POST['ky'];
                            if(!empty($_POST['gd'])){
                                $gd = $_POST['gd'];
                                $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,sinhvien,diem,monhoc 
                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.diemsv 
                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon=".$tenmon." and lophoc.Namhoc=".$namhoc." and lophoc.Kyhoc=".$kyhoc." and lophoc.Giaidoan=".$gd;
                            }
                            else{
                                $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,sinhvien,diem,monhoc 
                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.diemsv 
                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon=".$tenmon." and lophoc.Namhoc=".$namhoc." and lophoc.Kyhoc=".$kyhoc;
                            }
                        }
                        else{
                            $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,die,sinhvienm,monhoc 
                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.diemsv 
                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon=".$tenmon." and lophoc.Namhoc=".$namhoc;
                        }
                    }
                    else{
                        $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,mo,sinhviennhoc 
                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.diemsv 
                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon=".$tenmon;
                    }
                }
                else{
                    $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc,sinhvien 
                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.diemsv
                                and sinhvien.CMTND =".$cmtnd;
                }
            }
        }
        $result = mysqli_query($conn,$sql);
        if (mysqli_num_rows($result) > 0) {
            echo"<table>";
            echo"<tr>";
            echo"<th>Mã môn</th>";
            echo"<th>Tên môn</th>";
            echo"<th>Điểm quá trình</th>";
            echo"<th>Điểm thi</th>";
            echo"<th>Điểm học phần</th>";
            echo"</tr>";
            while($row = mysqli_fetch_assoc($result)) {
                echo"<td>".$row['mamon']."</td>";
                echo"<td>".$row['tenmon']."</td>";
                echo"<td>".$row['diemqt']."</td>";
                echo"<td>".$row['diemthi']."</td>";
                echo"<td>".$row['diemhp']."</td>";
            }
            echo"</table>";
        }
        include('mysql-close.php');
    }
?>