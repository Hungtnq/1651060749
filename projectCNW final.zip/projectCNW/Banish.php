<?php 
    include('mysql-connect.php');
    $sql = "update diem set diemqt=0, diemthi=0, diemhp=0 where masv=".$_GET['sv']." and malop=".$_GET['lop'];
    mysqli_query($conn,$sql);
    include('mysql-close.php');
    header("location: class.php?id=".$_GET['id']."&lop=".$_GET['lop']);
?>