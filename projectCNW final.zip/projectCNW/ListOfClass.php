<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('mng-nav.php'); ?>
                    </div>
                    <div class="col-9 class-list">
                        <h4>Danh sách lớp: </h4>
                            <?php 
                                include('mysql-connect.php');
                                $sql = "select malop,tenlop,monhoc.tenmon,giangvien.tengv from lophoc,monhoc,giangvien where lophoc.mamon=monhoc.mamon and lophoc.magv=giangvien.magv";
                                $result = mysqli_query($conn,$sql);
                                if (mysqli_num_rows($result) > 0) {
                                    echo"<table>";
                                    echo"<tr>";
                                    echo"<th>Mã lớp</th>";
                                    echo"<th>Tên lớp</th>";
                                    echo"<th>Môn học</th>";
                                    echo"<th>Giảng viên</th>";
                                    echo"<th>Sửa</th>";
                                    echo"<th>Xóa</th>";
                                    echo"</tr>";
                                    while($row = mysqli_fetch_assoc($result)) {
                                        echo"<tr>";
                                        echo"<td>".$row['malop']."</td>";
                                        echo"<td>".$row['tenlop']."</td>";
                                        echo"<td>".$row['tenmon']."</td>";
                                        echo"<td>".$row['tengv']."</td>";
                                        $lop = $row['malop'];
                                        echo"<td><button onclick=\"window.location.href='updateClass.php?lop=".$lop."'\">Sửa</button></td>";
                                        echo"<td><button data-toggle='modal' data-target='#delClass'>Xóa</button></td>";
                                        echo"</tr>";
                                    }
                                    echo"</table>";    
                                }
                                include('mysql-close.php');
                            ?>
                        <br>
                        <button class="add-class">Thêm lớp</button>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="delClass" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Xóa lớp</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Bạn có chắc muốn xóa lớp ?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Không</button>
                        <?php echo"<button type='button' onclick=\"window.location.href='delClass.php?lop=".$lop."'\" class='btn btn-primary'>Xóa</button>"; ?>
                    </div>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>