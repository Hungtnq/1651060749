<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('mng-nav.php'); ?>
                    </div>
                    <div class="col-9 class-list">
                        <h4>Danh sách lớp: </h4>
                            <?php 
                                include('mysql-connect.php');
                                $sql = "select malop,tenlop,monhoc.tenmon,giangvien.tengv from lophoc,monhoc,giangvien where lophoc.mamon=monhoc.mamon and lophoc.magv=giangvien.magv";
                                $result = mysqli_query($conn,$sql);
                                if (mysqli_num_rows($result) > 0) {
                                    echo"<table>";
                                    echo"<tr>";
                                    echo"<th>Mã lớp</th>";
                                    echo"<th>Tên lớp</th>";
                                    echo"<th>Môn học</th>";
                                    echo"<th>Giảng viên</th>";
                                    echo"<th>Sửa</th>";
                                    echo"</tr>";
                                    while($row = mysqli_fetch_assoc($result)) {
                                        echo"<tr>";
                                        echo"<td>".$row['malop']."</td>";
                                        echo"<td>".$row['tenlop']."</td>";
                                        echo"<td>".$row['tenmon']."</td>";
                                        echo"<td>".$row['tengv']."</td>";
                                        $lop = $row['malop'];
                                        echo"<td><button onclick=\"window.location.href='updateClass.php?lop=".$lop."'\">Sửa</button></td>";
                                        echo"</tr>";
                                    }
                                    echo"</table>";    
                                }
                                include('mysql-close.php');
                            ?>
                        <br>
                        <button class="add-class">Thêm lớp</button>
                    </div>
                </div>
            </div>
            
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>