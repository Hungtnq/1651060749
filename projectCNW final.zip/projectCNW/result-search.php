        <header>
            <?php include('header.php'); ?> 
        </header>
        <main>
            <div class="container">
                <form class="r-search" action="result-search.php" method="post">
                    <div class="row">
                        <div class="col-4">
                            <label for="">Mã sinh viên</label>
                            <input type="text" name="masv" id="">
                        </div>
                        <div class="col-4">
                            <label for="">Số CMTND</label>
                            <input type="text" name="CMTND" id="">
                        </div>
                        <div class="col-4">
                            <label for="">Môn học</label>
                            <input type="text" name="tenmon" id="">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-4">
                            <label for="">Năm học</label>
                            <select name="nam" id="">
                                <option value=""></option>
                                <option value="2018-2019">2018-2019</option>
                                <option value="2019-2020">2019-2020</option>
                                <option value="2020-2021">2020-2021</option>
                                <option value="2021-2022">2021-2022</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <label for="">Kỳ</label>
                            <select name="ky" id="">
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">song song</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <label for="">Giai đoạn</label>
                            <select name="gd" id="">
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                            </select>
                        </div>
                    </div>
                    <br>
                    <input type="submit" value="Tra cứu">
                </form>
                <?php 
                    if(!empty($_POST)){
                        include('mysql-connect.php');
                        if(!empty($_POST['masv'])){
                            $masv = $_POST['masv'];
                            if(!empty($_POST['tenmon'])){
                                $tenmon = $_POST['tenmon'];
                                if(!empty($_POST['nam'])){
                                    $namhoc = $_POST['nam'];
                                    if(!empty($_POST['ky'])){
                                        $kyhoc = $_POST['ky'];
                                        if(!empty($_POST['gd'])){
                                            $gd = $_POST['gd'];
                                            $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                                            and diem.masv =".$masv." and monhoc.tenmon='".$tenmon."' and lophoc.Namhoc='".$namhoc."' and lophoc.Kyhoc='".$kyhoc."' and lophoc.Giaidoan='".$gd."'";
                                        }
                                        else{
                                            $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                                            and diem.masv =".$masv." and monhoc.tenmon='".$tenmon."' and lophoc.Namhoc='".$namhoc."' and lophoc.Kyhoc='".$kyhoc."'";
                                        }
                                    }
                                    else{
                                        $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop
                                            and diem.masv =".$masv." and monhoc.tenmon='".$tenmon."' and lophoc.Namhoc='".$namhoc."'";
                                    }
                                }
                                else{
                                    $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                                            and diem.masv =".$masv." and monhoc.tenmon= '".$tenmon."'";
                                }
                            }
                            else{
                                $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc 
                                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop 
                                            and diem.masv =".$masv;
                            }
                        }
                        else{
                            if(!empty($_POST['CMTND'])){
                                $cmtnd = $_POST['CMTND'];
                                if(!empty($_POST['tenmon'])){
                                    $tenmon = $_POST['tenmon'];
                                    if(!empty($_POST['nam'])){
                                        $namhoc = $_POST['nam'];
                                        if(!empty($_POST['ky'])){
                                            $kyhoc = $_POST['ky'];
                                            if(!empty($_POST['gd'])){
                                                $gd = $_POST['gd'];
                                                $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,sinhvien,diem,monhoc 
                                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.masv 
                                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon='".$tenmon."' and lophoc.Namhoc='".$namhoc."' and lophoc.Kyhoc='".$kyhoc."' and lophoc.Giaidoan='".$gd."'";
                                            }
                                            else{
                                                $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,sinhvien,diem,monhoc 
                                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.masv 
                                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon='".$tenmon."' and lophoc.Namhoc='".$namhoc."' and lophoc.Kyhoc='".$kyhoc."'";
                                            }
                                        }
                                        else{
                                            $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,sinhvien,monhoc 
                                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.masv 
                                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon='".$tenmon."' and lophoc.Namhoc='".$namhoc."'";
                                        }
                                    }
                                    else{
                                        $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc,sinhvien 
                                                where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.masv 
                                                and sinhvien.CMTND =".$cmtnd." and monhoc.tenmon='".$tenmon."'";
                                    }
                                }
                                else{
                                    $sql = "select lophoc.mamon, monhoc.tenmon, diem.diemqt, diem.diemthi, diem.diemhp from lophoc,diem,monhoc,sinhvien 
                                            where lophoc.mamon = monhoc.mamon and diem.malop = lophoc.malop and diem.masv = sinhvien.masv
                                            and sinhvien.CMTND =".$cmtnd;
                                }
                            }
                        }
                        if(isset($sql)){
                            $result = mysqli_query($conn,$sql);
                            if($result){
                                if (mysqli_num_rows($result) > 0) {
                                    echo"<table>";
                                    echo"<tr>";
                                    echo"<th>Mã môn</th>";
                                    echo"<th>Tên môn</th>";
                                    echo"<th>Điểm quá trình</th>";
                                    echo"<th>Điểm thi</th>";
                                    echo"<th>Điểm học phần</th>";
                                    echo"</tr>";
                                    while($row = mysqli_fetch_assoc($result)) {
                                        echo"<td>".$row['mamon']."</td>";
                                        echo"<td>".$row['tenmon']."</td>";
                                        echo"<td>".$row['diemqt']."</td>";
                                        echo"<td>".$row['diemthi']."</td>";
                                        echo"<td>".$row['diemhp']."</td>";
                                    }
                                    echo"</table>";
                                }
                                else{
                                    echo"Không tìm thấy";
                                }
                            }
                            else{
                                echo"Không tìm thấy";
                            }
                        }
                        else{
                            echo"Không tìm thấy";
                        }
                        include('mysql-close.php');
                    }    
                ?>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>