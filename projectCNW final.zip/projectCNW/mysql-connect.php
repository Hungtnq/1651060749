<?php
    $conn = mysqli_connect('localhost','root','','project_1');
    if(!$conn){
        die('Lỗi kết nối tới CSDL');
    }
    mysqli_set_charset($conn, 'UTF8');
?>