<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('mng-nav.php'); ?>
                    </div>
                    <div class="col-9 class-list">
                        <h4>Chọn lớp: </h4>
                        <?php 
                            include('mysql-connect.php');
                            $sql = "select giangvien.magv,giangvien.tengv,nganh.tenNg,khoa.tenK from khoa,nganh,giangvien where nganh.maK=khoa.maK and nganh.maNg=giangvien.maNg";
                            $result = mysqli_query($conn,$sql);
                            if (mysqli_num_rows($result) > 0) {
                                echo"<table>";
                                echo"<tr>";
                                echo"<th>Mã giảng viên</th>";
                                echo"<th>Tên giảng viên</th>";
                                echo"<th>Ngành</th>";
                                echo"<th>Khoa</th>";
                                echo"<th>Sửa</th>";
                                echo"</tr>";
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo"<tr>";
                                    echo"<td>".$row['magv']."</td>";
                                    echo"<td>".$row['tengv']."</td>";
                                    echo"<td>".$row['tenNg']."</td>";
                                    echo"<td>".$row['tenK']."</td>";
                                    $gv = $row['magv'];
                                    echo"<td><button onclick=\"window.location.href='updTeacher.php?gv=".$gv."'\">Sửa</button></td>";
                                    echo"</tr>";
                                }
                                echo"</table>";    
                            }
                            include('mysql-close.php');
                        ?>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>