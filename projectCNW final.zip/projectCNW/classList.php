        <header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 class-list">
                        <h4>Chọn lớp: </h4>
                        <?php 
                            include('mysql-connect.php');
                            $sql = "SELECT lophoc.malop, lophoc.tenlop, monhoc.tenmon, giangvien.tengv from lophoc,monhoc,giangvien
                            WHERE lophoc.mamon = monhoc.mamon and giangvien.magv = lophoc.magv and giangvien.id  = ".$_GET['id'];
                            $result = mysqli_query($conn,$sql);
                            if (mysqli_num_rows($result) > 0) {
                                echo"<table>";
                                echo"<tr>";
                                echo"<th>Mã lớp</th>";
                                echo"<th>Tên lớp</th>";
                                echo"<th>Môn học</th>";
                                echo"<th>Giảng viên</th>";
                                echo"<th>Số lượng sinh viên</th>";
                                echo"<th>Lựa chọn</th>";
                                echo"</tr>";
                                while($row = mysqli_fetch_assoc($result)) {
                                    $sql1 = "select count(diem.masv) as soluongSV from diem where malop = ".$row['malop'];
                                    $result1 = mysqli_query($conn,$sql1);
                                    if ($result1){
                                        $row1 = mysqli_fetch_assoc($result1);
                                    }
                                    else{
                                        $row1['soluongSV'] = 0;
                                    }
                                    echo"<tr>";
                                    echo"<td>".$row['malop']."</td>";
                                    echo"<td>".$row['tenlop']."</td>";
                                    echo"<td>".$row['tenmon']."</td>";
                                    echo"<td>".$row['tengv']."</td>";
                                    echo"<td>".$row1['soluongSV']."</td>";
                                    $lop = $row['malop'];
                                    echo"<td><button onclick=\"window.location.href='class.php?id=".$_GET['id']."&lop=".$lop."'\">Chọn</button></td>";
                                    echo"</tr>";
                                }
                                echo"</table>";    
                            }
                            else{
                                echo"fail";
                            }
                            include('mysql-close.php');
                        ?>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>