<h3 style="padding-bottom:20px">Danh mục chính</h3>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 1</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 2</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 3</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 4</a>
                            </li>
                        </ul>