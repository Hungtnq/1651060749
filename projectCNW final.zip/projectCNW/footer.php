<div class="container">
            <div class="row">
                <div class="col-3 LH1">
                    <p>TRƯỜNG ĐẠI HỌC THỦY LỢI</p>
                    <p>Địa chỉ : 175 TÂY SƠN, ĐỐNG ĐA, HÀ NỘI.</p>
                    <p>Điện thoại: (024) 3852 2201 - Fax: (024) 3563 3351</p>
                    <p>Email: phonghcth@tlu.edu.vn</p>
                </div>
                <div class="col-3 LH2">
                    <p>TRƯỜNG ĐẠI HỌC THỦY LỢI - CƠ SỞ 2</p>
                    <p>Phường An Thạnh - TX Thuận An - Tỉnh Bình Dương</p>
                    <p>Điện thoại: (84).650.3748 620</p>
                    <p>Fax:(84).650.3833 489</p>
                </div>
                <div class="col-6 map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.636969967549!2d105.822591115332!3d21.00718449388958!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac818ff3aa3f%3A0x2280b664f341f50f!2zMTc1IFTDonkgU8ahbiwgVHJ1bmcgTGnhu4d0LCDEkOG7kW5nIMSQYSwgSMOgIE7hu5lpLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1577435480206!5m2!1svi!2s" width="600" height="200" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
            </div>
            <div class="row note">
                <p>Lưu ý : Sản phẩm hoàn toàn dành cho mục đích học tập và không hề có thật! Mọi thông tin trùng lặp đều là vô tình</p>
            </div>
        </div>