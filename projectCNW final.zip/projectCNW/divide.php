<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 class">
                        <h4>Lớp: </h4>
                        <?php echo"An toàn bảo mật thông tin 58TH1.1"; ?>
                        <div class="add-body">
                            <div class="add-block">
                                <form action="divide.php"></form>
                                <input type="text" name="name-field" placeholder="Tên đầu điểm" class="name-field">
                                <input type="text" name="point-field" placeholder="Trọng số đầu điểm" class="point-field">
                                <input class="add-btn col-3" type="submit" value="Thêm đầu điểm">
                            </div>
                            <br>
                            <table class="tasks" id="tasks-list">
                                <tr>
                                    <th>Tên đầu điểm</th>
                                    <th>Trọng số</th>
                                    <th>Xóa</th>
                                </tr>
                                <tr class="task">
                                    <td class="task-text col-2">
                                        Task 1
                                    </td>
                                    <td class="task-point col-2">
                                        0.15
                                    </td>
                                    <td class="task-remove col-3">
                                        <button class="rmv">Xóa</button>
                                    </td>
                                </tr>
                                <tr class="task">
                                    <td class="task-text col-2">
                                        Task 2
                                    </td>
                                    <td class="task-point col-2">
                                        0.2
                                    </td>
                                    <td class="task-remove col-3">
                                        <button class="rmv">Xóa</button>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php
    // if(!empty($_POST)){
    //     include('mysql-connect.php');
    //     $sql = "alter table lophoc add ".$_POST['name-field']. " int";
    //     $sql .="create trigger realMark on  lophoc
    //             after insert,update
    //             as
    //             if insert(".$_POST['name-field'].") or update(".$_POST['name-field'].")
    //             begin
    //                 update lophoc set ".$_POST['name-field']." = ".$_POST['name-field']." * ".$_POST['point-field']."
    //                 where malop = ".$IDlop."
    //             end";
    //     mysqli_query($conn,$sql);
    //     include('mysql-close.php');
    // }
?>