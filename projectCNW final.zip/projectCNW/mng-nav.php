<h3 style="padding-bottom:20px">Danh mục chính</h3>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="ListOfClass.php">Danh sách lớp</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="TeacherList.php">Danh sách giảng viên</a>
                            </li>
                            <li class="nav-item">
                                <?php 
                                    $link = "changePass.php?id=".$_SESSION['user_id'];
                                    echo"<a class='nav-link' href=".$link.">Đổi mật khẩu</a>" 
                                ?>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Chức năng 4</a>
                            </li>
                        </ul>