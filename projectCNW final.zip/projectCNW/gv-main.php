<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                        <?php 
                            include('mysql-connect.php');
                            $sql = "select  giangvien.magv, giangvien.tengv, giangvien.gioitinh, giangvien.ngaysinh, giangvien.CMTND, giangvien.quequan, nganh.tenNg, khoa.tenK, taikhoan.email 
                            from giangvien,taikhoan,nganh,khoa
                            where giangvien.maNg = nganh.maNg and nganh.maK = khoa.maK and taikhoan.id = giangvien.id and giangvien.id = ".$_GET['id'];
                            $result = mysqli_query($conn,$sql);
                            if(mysqli_num_rows($result) == 1){
                                $row = mysqli_fetch_assoc($result);
                            }
                            echo"<p>";
                            echo"<h4>Thông tin giảng viên</h4>";
                            echo"<label for=''>Mã giảng viên: </label>";
                            echo $row['magv'];
                            echo"</p>";
                            echo"<p>";
                            echo"<label for=''>Ngành:</label>";
                            echo $row['tenNg'];
                            echo"</p>";
                            echo"<p>";
                            echo"<label for=''>Khoa:</label>";
                            echo $row['tenK'];
                            echo"</p>";
                            echo"<p>";
                            echo"<label>Họ và tên: </label>";
                            echo $row['tengv'];
                            echo"</p>";
                            echo"<p>";
                            echo"<label for=''>Ngày sinh: </label>";
                            echo $row['ngaysinh'];
                            echo"</p>";
                            echo"<label for=''>Giới tính: </label>";
                            echo $row['gioitinh'];
                            echo"</p>";
                            echo"<label for=''>Số CMTND/CCCD: </label>";
                            echo $row['CMTND'];
                            echo"</p>";
                            echo"<p>";
                            echo"<label for=''>Email: </label>";
                            echo $row['email'];
                            echo"</p>";
                            echo"<p>";
                            echo"<label for=''>Quê quán: </label>";
                            echo $row['quequan'];
                            echo"</p>";
                        ?>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>