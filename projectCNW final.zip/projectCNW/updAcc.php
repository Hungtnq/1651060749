<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('admin-nav.php'); ?>
                    </div>
                    <div class="col-9">
                        <h4>Sửa tài khoản: </h4>
                        <?php 
                            include('mysql-connect.php');
                            $sql = "select taikhoan.tenTK, taikhoan.email, taikhoan.chucvu from taikhoan where id = ".$_GET['id'];
                            $result = mysqli_query($conn,$sql);
                            if($result){
                                if(mysqli_num_rows($result) == 1){
                                    $row = mysqli_fetch_assoc($result);
                                    if($row['chucvu'] == 'sinhvien'){
                                        $sql2 = "select sinhvien.masv as ma, sinhvien.tensv as ten, sinhvien.quequan, sinhvien.ngaysinh, sinhvien.gioitinh, sinhvien.CMTND, nganh.tenNg, nganh.maNg from sinhvien,nganh
                                        where sinhvien.maNg = nganh.maNg and sinhvien.id =".$_GET['id'];
                                        $result2 = mysqli_query($conn,$sql2);
                                        if($result2){
                                            if(mysqli_num_rows($result2) == 1){
                                                $row2 = mysqli_fetch_assoc($result2);
                                            }
                                        }
                                    }
                                    if($row['chucvu'] == 'giangvien'){
                                        $sql2 = "select giangvien.magv as ma, giangvien.tengv as ten, giangvien.quequan, giangvien.ngaysinh, giangvien.gioitinh, giangvien.CMTND, nganh.tenNg, nganh.maNg from giangvien,nganh
                                        where giangvien.maNg = nganh.maNg and giangvien.id =".$_GET['id'];
                                        $result2 = mysqli_query($conn,$sql2);
                                        if($result2){
                                            if(mysqli_num_rows($result2) == 1){
                                                $row2 = mysqli_fetch_assoc($result2);
                                            }
                                        }
                                    }
                                    if($row['chucvu'] == 'quanly'){
                                        $sql2 = "select quanly.maql as ma, quanly.tenql as ten, quanly.quequan, quanly.ngaysinh, quanly.gioitinh, quanly.CMTND from quanly
                                        where quanly.id =".$_GET['id'];
                                        $result2 = mysqli_query($conn,$sql2);
                                        if($result2){
                                            if(mysqli_num_rows($result2) == 1){
                                                $row2 = mysqli_fetch_assoc($result2);
                                                $row2['tenNg'] = null;
                                            }
                                        }
                                    }
                                    if($row['chucvu'] == 'quantri'){
                                        $sql2 = "select quantri.maqt as ma, quantri.tenqt as ten, quantri.quequan, quantri.ngaysinh, quantri.gioitinh, quantri.CMTND from quantri
                                        where quantri.id =".$_GET['id'];
                                        $result2 = mysqli_query($conn,$sql2);
                                        if($result2){
                                            if(mysqli_num_rows($result2) == 1){
                                                $row2 = mysqli_fetch_assoc($result2);
                                                $row2['tenNg'] = null;
                                            }
                                        }
                                    }
                                }
                            }
                            $link = "updAcc.php?id=".$_GET['id'];
                            echo"<form action=".$link." , method = 'post'>";
                            echo"<label class='col-2' for=''>Tài khoản:</label>";
                            echo"<input type='text' name='tentk' class='col-5' id='' value=".$row['tenTK'].">";
                            echo"<br>";
                            echo"<label class='col-2' for=''>Email:</label>";
                            echo"<input type='text' name='email' class='col-5' id='' value=".$row['email'].">";
                            echo"<br>";
                            echo"<label class='col-2' for=''>Mã:</label>";
                            echo"<input type='text' name='ma' class='col-5' id='' value=".$row2['ma'].">";
                            echo"<br>";
                            ?>
                            <label class='col-2' for=''>Họ và tên:</label>
                            <input type='text' name='HvT' class='col-5' id='' value="<?php echo $row2['ten'] ?>">
                            <br>
                            <label class='col-2' for=''>Quê quán:</label>
                            <input type='text' name='qq' class='col-5' id='' value="<?php echo $row2['quequan'] ?>">
                            <br>
                            <?php
                            echo"<label class='col-2' for=''>Ngày sinh:</label>";
                            echo"<input type='text' name='ns' class='col-5' id='' value=".$row2['ngaysinh'].">";
                            echo"<br>";
                            echo"<label class='col-2' for=''>Giới tính:</label>";
                            echo"<select name='gt' id=''>";
                            echo"<option value=".$row2['gioitinh'].">".$row2['gioitinh']."</option>";
                            echo"<option value='nam'>Nam</option>";
                            echo"<option value='nu'>Nữ</option>";
                            echo"</select>";
                            echo"<br>";
                            echo"<label class='col-2' for=''>Số CMTND:</label>";
                            echo"<input type='text' name='cmtnd' class='col-5' id='' value=".$row2['CMTND'].">";
                            echo"<br>";
                            echo"<label class='col-2' for=''>Chức vụ:</label>";
                            echo"<select name='cv' id='' >";
                            echo"<option value=".$row['chucvu'].">".$row['chucvu']."</option>";
                            echo"<option value='sinhvien'>sinh viên</option>";
                            echo"<option value='giangvien'>giảng viên</option>";
                            echo"<option value='quanly'>quản lý</option>";
                            echo"<option value='quantri'>quản trị</option>";
                            echo"</select>";
                            echo"<br>";
                            echo"<label class='col-2' for=''>Ngành:</label>";
                                echo"<select name='ng' id='' >";
                                echo"<option value=".$row2['maNg'].">".$row2['tenNg']."</option>";
                                $sql_ng = "select tenNg from nganh";
                                $result_ng = mysqli_query($conn,$sql_ng);
                                while($row_ng = mysqli_fetch_assoc($result_ng)){
                                    echo"<option value='".$row_ng['tenNg']."'>".$row_ng['tenNg']."</option>";
                                }
                                echo"</select>";
                                include('mysql-close.php');
                            echo"<br><br>";
                            echo"<input type='submit' value='Sửa tài khoản'>";
                            echo"</form>";

                        ?>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php 
    if(!empty($_POST)){
        include('mysql-connect.php');
        if($_POST['cv'] == 'sinhvien'){
            $sql3 = "update taikhoan set tenTK = '".$_POST['tentk']."', email = '".$_POST['email']."', chuc vu = '".$_POST['cv']."' 
            where id = ".$_GET['id'];
            $sql4 = "update sinhvien 
            set masv = '".$_POST['ma']."', tensv = '".$_POST['HvT']."', quequan = '".$_POST['qq']."', ngaysinh = '".$_POST['ns']."', gioitinh = '".$_POST['gt']."', CMTND = '".$_POST['cmtnd']."', maNg = '".$_POST['ng']."'
            where id = ".$_GET['id'];
        }
        if($_POST['cv'] == 'giangvien'){
            $sql3 = "update taikhoan set tenTK = '".$_POST['tentk']."', email = '".$_POST['email']."', chuc vu = '".$_POST['cv']."' 
            where id = ".$_GET['id'];
            $sql4 = "update giangvien 
            set magv = '".$_POST['ma']."', tengv = '".$_POST['HvT']."', quequan = '".$_POST['qq']."', ngaysinh = '".$_POST['ns']."', gioitinh = '".$_POST['gt']."', CMTND = '".$_POST['cmtnd']."', maNg = '".$_POST['ng']."'
            where id = ".$_GET['id'];
        }
        if($_POST['cv'] == 'quanly'){
            $sql3 = "update taikhoan set tenTK = '".$_POST['tentk']."', email = '".$_POST['email']."', chuc vu = '".$_POST['cv']."' 
            where id = ".$_GET['id'];
            $sql4 = "update quanly 
            set maql = '".$_POST['ma']."', tenql = '".$_POST['HvT']."', quequan = '".$_POST['qq']."', ngaysinh = '".$_POST['ns']."', gioitinh = '".$_POST['gt']."', CMTND = '".$_POST['cmtnd']."'
            where id = ".$_GET['id'];
        }
        if($_POST['cv'] == 'quantri'){
            $sql3 = "update taikhoan set tenTK = '".$_POST['tentk']."', email = '".$_POST['email']."', chuc vu = '".$_POST['cv']."' 
            where id = ".$_GET['id'];
            $sql4 = "update quantri
            set maqt = '".$_POST['ma']."', tenqt = '".$_POST['HvT']."', quequan = '".$_POST['qq']."', ngaysinh = '".$_POST['ns']."', gioitinh = '".$_POST['gt']."', CMTND = '".$_POST['cmtnd']."'
            where id = ".$_GET['id'];
        }
        $result3 = mysqli_query($conn,$sql3);
        $result4 = mysqli_query($conn,$sql4);
        include('mysql-close.php');
        header("location:accList.php");
    }
?>