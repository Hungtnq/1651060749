<?php 
    include('mysql-connect.php');
    $sql = "delete from lophoc WHERE malop =".$_GET['lop'];
    mysqli_query($conn,$sql);
    include('mysql-close.php');
    header('Location:ListOfClass.php');
?>