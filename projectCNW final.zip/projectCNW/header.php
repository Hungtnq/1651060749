<?php 
    session_start();
    if ( isset( $_SESSION['user_id'] ) ) {
        $checked = true;
    } else {
        $checked = false;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/mystyle.css">
    <script src="js/jquery.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <div class="container">
        <div class="top-head">
            <div class="row">
                <div class="col-8 logo">
                    <a href="#"><img src="img/logo.png" alt=""></a>
                </div>
                <div class="col-4 title">
                    <h3>Hệ Thống Quản Lý</h3>
                    <h3>Trường Đại Học Thủy Lợi</h3>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="nav-bar">
            <nav class="navbar navbar-expand-lg">
                <div class="collapse navbar-collapse container" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item home">
                            <a class='nav-link' href='index.php'>Trang Chủ</a>
                        </li>
                        <li class="nav-item result-search">
                            <a class='nav-link' href='result-search.php'>Tra cứu điểm</a>
                        </li>
                        <li class="nav-item support">
                            <a class='nav-link' href='support.php'>Hỗ trợ</a>
                        </li>
                        <?php 
                            if(!$checked){
                                echo"<li class='nav-item login'>";
                                echo"<a class='nav-link' href='' type='button'data-toggle='modal' data-target='#exampleModal'>Đăng nhập</a>";
                                echo"</li>";
                            }
                        ?>
                    </ul>
                    <ul class="navbar-nav form-inline my-2 my-lg-0">
                        <?php 
                            if($checked){
                                $ID = $_SESSION['user_id'];
                                require('mysql-connect.php');
                                $sql = "select chucvu from taikhoan where id='".$ID."'";
                                $result = mysqli_query($conn,$sql);
                                if (mysqli_num_rows($result) == 1) {
                                    $row = mysqli_fetch_assoc($result);
                                    if($row["chucvu"] == "sinhvien"){
                                        $link = "sv-main.php?id=".$ID;
                                    }
                                    else if($row["chucvu"] == "giangvien"){
                                        $link = "gv-main.php?id=".$ID;
                                    }
                                    else if($row["chucvu"] == "quanly"){
                                        $link = "mng-main.php?id=".$ID;
                                    }
                                    else if($row["chucvu"] == "quantri"){
                                        $link = "admin-main.php?id=".$ID;
                                    }
                                }
                                require('mysql-close.php');
                                echo"<li class='nav-item welcome'>";
                                echo"<a class='nav-link' href='".$link."'>Trang cá nhân</a>";
                                echo"</li>";
                                echo"<li class='nav-item logout'>";
                                echo"<a class='nav-link' href='logout.php'>Đăng xuất</a>";
                                echo"</li>";
                            }
                        ?>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Đăng nhập</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="login.php" method="post">
                        <label for="">Tài khoản</label>
                        <input type="text" name="userName" id="name">
                        <br>
                        <label for="">Mật khẩu</label>
                        <input type="password" name="userPass" id="pass">
                        <br>
                        <br>
                        <input class="submit" type="submit" value="Đăng nhập">
                    </form>
                </div>
            </div>
        </div>
    </div>