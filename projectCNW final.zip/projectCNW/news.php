<header>
            <?php include('header.php'); ?> 
        </header>
        <main>
        <div class="container">
                <?php 
                    include('mysql-connect.php');
                    $sql = "select * from baiviet where mabv = ".$_GET['bv'];
                    $result = mysqli_query($conn,$sql);
                    $row = mysqli_fetch_assoc($result);
                    echo"<h3>".$row['tieude']."</h3>";
                    echo"<p>".$row['noidung']."</p>";
                    include('mysql-connect.php');
                ?>
            </div>
        </main>
        <footer>
            <?php include('footer.php') ?>
        </footer>
    </body>
</html>