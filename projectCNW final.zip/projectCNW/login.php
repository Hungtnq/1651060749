<?php 
    session_start();
    require('mysql-connect.php');
    if(isset($_POST)){
        $name = $_POST['userName'];
        $pass = $_POST['userPass'];
        $sql = "select * from taikhoan where tenTK = '$name' and trangthai = 1";
        $result = mysqli_query($conn,$sql);
        if($result){
            if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    $time = row['thoigian'];
                    $realPass = md5($pass.$time);
                    $sql2 = "select * from taikhoan where tenTK = '$name' and matkhau = '$realPass'";
                    $result2 = mysqli_query($conn,$sql);
                    if (mysqli_num_rows($result2) == 1) {
                        while($row2 = mysqli_fetch_assoc($result2)){
                            $ID = $row2['id'];
                            $_SESSION['user_id'] = $ID;
                            if($row2["chucvu"] == "sinhvien"){
                                header("Location: sv-main.php?id=".$ID);
                            }
                            else if($row2["chucvu"] == "giangvien"){
                                header("Location: gv-main.php?id=".$ID);
                            }
                            else if($row2["chucvu"] == "quanly"){
                                header("Location: mng-main.php?id=".$ID);
                            }
                            else if($row2["chucvu"] == "quantri"){
                                header("Location: admin-main.php?id=".$ID);
                            }
                        }
                    }
                }
            } 
            else {
                echo "sai ten dang nhap hoc mat khau";
            }
        }
    }
    require('mysql-close.php');
?>