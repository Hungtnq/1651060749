        <header>
                    <?php include('header.php'); ?>
        </header>
        <main>
        <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('sv-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                        <?php 
                            $error = "";
                            echo"<h4>Đổi mật khẩu</h4>";
                            $link = "changePass.php?id=".$_GET['id'];
                            echo"<form action=".$link." method='post'>";
                                echo"<label class='col-3' for=''>Mật khẩu hiện tại</label>";
                                echo"<input type='password' name='curPass' id=''>";
                                echo"<br><br>";
                                echo"<label class='col-3' for=''>Mật khẩu mới</label>";
                                echo"<input type='password' name='newPass' id=''>";
                                echo"<br><br>";
                                echo"<label class='col-3' for=''>Nhập lại mật khẩu mới</label>";
                                echo"<input type='password' name='confPass' id=''>";
                                echo"<br><br>";
                                echo"<input type='submit' value='Đổi mật khẩu'>";
                                echo"</form>";
                        ?>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php 
    if(!empty($_POST)){
        include('mysql-connect.php');
        if($_POST['newPass'] != $_POST['confPass']){
            $error = "mật khẩu mới không trùng với mật khẩu được xác nhận";
        }
        else{
            $sql = "select * from taikhoan where id = ".$_GET['id'];
            $result = mysqli_query($conn,$sql);
            if($result){
                if(mysqli_num_rows($result) == 1){
                    $row = mysqli_fetch_assoc($result);
                    $check = md5($_POST['curPass'].$row['thoigian']);
                    echo $check." - ".$row['matkhau'];
                    if($check == $row['matkhau']){
                        $newPass = md5($_POST['newPass'].$row['thoigian']);
                        $sql2 = "update taikhoan set matkhau = '".$newPass."' where id = ".$_GET['id'];
                        mysqli_query($conn,$sql2);
                    }
                    else{
                        $error = "Nhập sai mật khẩu hiện tại";
                    }
                }
            }
            else{
                echo"wrong";
            }
        }
        include('mysql-close.php');
    }
?>