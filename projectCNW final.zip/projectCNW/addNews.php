<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('admin-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                    <h4>Thêm bài viết: </h4>
                        <form action="addNews.php" method="post">
                            <div class="row">
                                <label class="col-2" for="">Mã bài viết</label>
                                <input type="text" name="mabv" class="col-5" id="" required>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-2" for="">Tiêu đề</label>
                                <input type="text" name="td" class="col-5" id="" required>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-2" for="">Tóm tắt</label>
                                <textarea name="tt" id="" cols="60" rows="5" required></textarea>
                            </div>
                            <br>
                            <div class="row">
                                <label class="col-2" for="">Nội dung</label>
                                <textarea name="nd" id="" cols="60" rows="10" required></textarea>
                            </div>
                            <br>
                            <label class="col-2" for="">Tác giả</label>
                            <?php 
                                include('mysql-connect.php');
                                echo"<select name='tg' id='' required>";
                                echo"<option value=''></option>";
                                $sql_tg = "select maqt,tenqt from quantri";
                                $result_tg = mysqli_query($conn,$sql_tg);
                                while($row_tg = mysqli_fetch_assoc($result_tg)){
                                    echo"<option value='".$row_tg['maqt']."'>".$row_tg['tenqt']."</option>";
                                }
                                echo"</select>";
                                include('mysql-close.php');
                            ?>
                            <br><br>
                            <div class="row">
                                <div class="col-2"></div>
                                <input type="submit" value="Thêm bài viết">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php 
    if(!empty($_POST)){
        include('mysql-connect.php');
        $date = date('Y/m/d', time());
        $sql = "insert into baiviet values('".$_POST['mabv']."', '".$_POST['td']."', '".$_POST['tt']."', '".$_POST['nd']."', '".$_POST['tg']."', '".$date."')";
        mysqli_query($conn,$sql);
        include('mysql-close.php');
    }
    else {
        echo "fail";
    }
?>