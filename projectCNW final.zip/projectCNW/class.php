<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 class">
                        <?php 
                            if(!empty($_GET)){
                                $lop = $_GET['lop'];
                                include('mysql-connect.php');
                                $sql = "SELECT diem.masv, sinhvien.tensv, diem.diemqt, diem.diemthi, diem.diemhp from sinhvien,diem where sinhvien.masv=diem.masv and diem.malop=".$lop;
                                $result = mysqli_query($conn,$sql);
                                $sql1 = "select tenlop from lophoc where malop=".$lop;
                                if (mysqli_num_rows($result) > 0) {
                                    echo"<h4>Lớp: ".mysqli_fetch_assoc(mysqli_query($conn,$sql1))['tenlop']."</h4>";
                                    echo"<table>";
                                    echo"<tr>";
                                    echo"<th>Mã sinh viên</th>";
                                    echo"<th>Tên sinh viên</th>";
                                    echo"<th>Điểm quá trình</th>";
                                    echo"<th>Điểm thi</th>";
                                    echo"<th>Điểm học phần</th>";
                                    echo"<th>Sửa điểm</th>";
                                    echo"<th>Cấm thi</th>";
                                    echo"</tr>";
                                    while($row = mysqli_fetch_assoc($result)) {
                                        echo"<tr>";
                                        echo"<td>".$row['masv']."</td>";
                                        echo"<td>".$row['tensv']."</td>";
                                        echo"<td>".$row['diemqt']."</td>";
                                        echo"<td>".$row['diemthi']."</td>";
                                        echo"<td>".$row['diemhp']."</td>";
                                        $sv = $row['masv'];
                                        echo"<td><button onclick=\"window.location.href='updPoint.php?id=".$_GET['id']."&lop=".$lop."&sv=".$sv."'\">Sửa điểm</button></td>";
                                        echo"<td><button>Cấm thi</button></td>";
                                        echo"</tr>";
                                    }
                                    echo"</table>";    
                                    echo"<br>";
                                    echo"<button class=\"updateStudentList\" onclick=\"window.location.href='addStu.php?id=".$_GET['id']."&lop=".$lop."'\">Thêm sinh viên</button>";
                                    echo"<span> </span>";
                                    echo"<button class=\"dividePoint\" onclick=\"window.location.href='divide.php?id=".$_GET['id']."&lop=".$lop."'\">Chỉnh sửa đầu điểm quá trình</button>";
                                }
                                include('mysql-close.php');
                            }
                            else{
                                echo"Lỗi";
                            }
                        ?>
                        
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>