$(document).ready(function(){
    //dang nhap va dang xuat
    $(".submit").click(function(){
            $(".modal").modal('toggle');
            $(".login").hide();
            $(".welcome").show();
            $(".logout").show();
    })
    $(".logout").click(function(){
        $(".login").show();
        $(".welcome").hide();
        $(".logout").hide();
    })
    $(".select-class").click(function(){
        window.location.href = 'class.php';
    })

    //them va xoa dau diem
    let addBtn = $('.add-btn');
    let name = $('.name-field');
    let point = $('.point-field');
    let tasks = $('.tasks');

    addBtn.on('click', function(){
        let newEle = `<tr class="task">
                        <td class="task-text col-2">
                            ${name.val()} 
                        </td>
                        <td class="task-point col-2">
                            ${point.val()}
                        </td>
                        <td class="task-remove col-3">
                            <button class="rmv">Xóa</button>
                        </td>
                    </tr>`;
        tasks.append(newEle);
        name.val('');
        point.val('');
    })
    tasks.on('click','.task-remove',function(){
        $(this).parent().remove();
    })

    //them va sua danh sach lop
    $(".update-class").click(function(){
        window.location.href="updateClass.php"
    })
    $(".add-class").click(function(){
        window.location.href="addClass.php"
    })

    // $('.updateStudentList').click(function(){
    //     window.location.href="addStu.php"
    // })
})