<header>
            <?php include('header.php'); ?> 
        </header>
        <main>
        <div class="container">
                <div class="row">
                    <div class="col-8">
                        <h3>Tin tức</h3>
                    </div>
                    <div class="col-4">
                        <h3>Thông báo</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="row">
                            <div class="col-7">
                                <div class="card">
                                    <img src="img/image011.jpg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <?php 
                                            include('mysql-connect.php');
                                            $sql = "select * from baiviet order by ngaydang desc";
                                            $result = mysqli_query($conn,$sql);
                                            while($row = mysqli_fetch_assoc($result)){
                                                $count = 1;
                                                echo"<a href='news.php?bv=".$row['mabv']."'>".$row['tieude']."</a>";
                                                echo"<p class='card-text'>".$row['tomtat']."</p>";
                                                if($count == 1){
                                                    break;
                                                }
                                            }
                                            include('mysql-connect.php');
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-5">
                                <ul class="news">
                                    <?php 
                                        include('mysql-connect.php');
                                        $sql = "select * from baiviet order by ngaydang desc";
                                        $result = mysqli_query($conn,$sql);
                                        while($row = mysqli_fetch_assoc($result)){
                                            $count = 1;
                                            echo"<li>";
                                            echo"<a href='news.php?bv=".$row['mabv']."'>".$row['tieude']."</a>";
                                            echo"<hr>";
                                            echo"</li>";
                                            if($count == 5){
                                                break;
                                            }
                                            $count = $count + 1;
                                        }
                                        include('mysql-connect.php');
                                    ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <ul class="announcement">
                            <?php 
                                include('mysql-connect.php');
                                $sql = "select * from baiviet order by ngaydang desc";
                                $result = mysqli_query($conn,$sql);
                                while($row = mysqli_fetch_assoc($result)){
                                    $count = 1;
                                    echo"<li>";
                                    echo"<a href='news.php?bv=".$row['mabv']."'>".$row['tieude']."</a>";
                                    echo"<hr>";
                                    echo"</li>";
                                    if($count == 5){
                                        break;
                                    }
                                    $count = $count + 1;
                                }
                                include('mysql-connect.php');
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php') ?>
        </footer>
    </body>
</html>