<header>
            <?php include('header.php'); ?> 
        </header>
        <main>
        <div class="container">
                <div class="row">
                    <div class="col-8">
                        <h3>Tin tức</h3>
                    </div>
                    <div class="col-4">
                        <h3>Thông báo</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="row">
                            <div class="col-7">
                                <div class="card">
                                    <img src="img/image011.jpg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                    <a href="#">Khai mạc đợt khảo sát chính thức phục vụ đánh giá ngoài 4 chương trình đào tạo </a>
                                    <p class="card-text">(TLU) – Ngày 26/12, Trường Đại học Thủy lợi diễn ra Khai mạc đợt khảo sát chính thức phục vụ đánh giá ngoài 4 chương trình đào tạo gồm Công nghệ ...</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-5">
                                <ul class="news">
                                    <li>
                                        <a href="">Khai mạc đợt khảo sát chính thức phục vụ đánh giá ngoài 4 chương trình đào tạo</a>
                                        <hr>
                                    </li>
                                    <li>
                                        <a href="">Đại học Thủy lợi là một trong 30 trường đại học Việt Nam có công bố quốc tế nhiều nhất </a>
                                        <hr>
                                    </li>
                                    <li>
                                        <a href="">Bế giảng khóa học bồi dưỡng tiếng Anh cho công chức thuộc Bộ Nông nghiệp và Phát triển nông thôn năm 2019 </a>
                                        <hr>
                                    </li>
                                    <li>
                                        <a href="">Khai mạc giải bóng đá cán bộ, giảng viên thành phố Hà Nội năm 2019 </a>
                                        <hr>
                                    </li>
                                    <li>
                                        <a href="">Gặp mặt cán bộ viên chức nghỉ hưu năm 2019 </a>
                                        <hr>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <ul class="announcement">
                            <li>
                                <a href="">Khai mạc đợt khảo sát chính thức phục vụ đánh giá ngoài 4 chương trình đào tạo</a>
                                <hr>
                            </li>
                            <li>
                                <a href="">Đại học Thủy lợi là một trong 30 trường đại học Việt Nam có công bố quốc tế nhiều nhất </a>
                                <hr>
                            </li>
                            <li>
                                <a href="">Bế giảng khóa học bồi dưỡng tiếng Anh cho công chức thuộc Bộ Nông nghiệp và Phát triển nông thôn năm 2019 </a>
                                <hr>
                            </li>
                            <li>
                                <a href="">Khai mạc giải bóng đá cán bộ, giảng viên thành phố Hà Nội năm 2019 </a>
                                <hr>
                            </li>
                            <li>
                                <a href="">Gặp mặt cán bộ viên chức nghỉ hưu năm 2019 </a>
                                <hr>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php') ?>
        </footer>
    </body>
</html>