<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('gv-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                        <h4>Thêm sinh viên vào lớp</h4>
                        <?php 
                            $link = "addStu.php?id=".$_GET['id']."&lop=".$_GET['lop'];
                            echo "<form action=".$link." method='post'>";
                        ?>
                            <div class="row">
                                <label class="col-2" for="">Mã sinh viên:   </label>
                                <input name="masv" class="col-5" type="text">
                            </div>
                            <br>
                            <input type="submit" value="Thêm">
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php
    if(!empty($_POST)){
        include('mysql-connect.php');
        if(!empty($_POST['masv'])){
            $sql = "Call addStuToClass_ma(".$_POST['masv'].",".$_GET['lop'].")";
        }
        mysqli_query($conn,$sql);
        include('mysql-close.php');
    }
?>