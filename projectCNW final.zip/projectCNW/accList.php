        <header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('admin-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                        <h4>Danh sách tài khoản</h4>
                        <?php 
                            include('mysql-connect.php');
                            $sql = "select id,tenTK,email,chucvu from taikhoan where trangthai = 1";
                            $result = mysqli_query($conn,$sql);
                            if (mysqli_num_rows($result) > 0) {
                                echo"<table>";
                                echo"<tr>";
                                echo"<th>Ten tai khoan</th>";
                                echo"<th>Email</th>";
                                echo"<th>Chức vụ</th>";
                                echo"<th>Sửa</th>";
                                echo"<th>Xóa</th>";
                                echo"</tr>";
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo"<tr>";
                                    echo"<td>".$row['tenTK']."</td>";
                                    echo"<td>".$row['email']."</td>";
                                    echo"<td>".$row['chucvu']."</td>";
                                    $id = $row['id'];
                                    echo"<td><button onclick=\"window.location.href='updAcc.php?id=".$id."'\">Sửa</button></td>";
                                    echo"<td><button data-toggle='modal' data-target='#delbtn'>Xóa</button></td>";
                                    echo"</tr>";
                                }
                                echo"</table>";    
                            }
                            include('mysql-close.php');
                        ?>
                        <br>
                        <button onclick="window.location.href='addAcc.php'">Thêm tài khoản</button>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="delbtn" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Xóa tài khoản</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Bạn có chắc muốn xóa tài khoản ?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Không</button>
                        <?php echo"<button type='button' onclick=\"window.location.href='delAcc.php?id=".$id."'\" class='btn btn-primary'>Xóa</button>"; ?>
                    </div>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>