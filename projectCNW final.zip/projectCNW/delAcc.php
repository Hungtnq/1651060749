<?php 
    include('mysql-connect.php');
    $sql = "UPDATE taikhoan SET trangthai = 0 WHERE taikhoan.id =".$_GET['id'];
    mysqli_query($conn,$sql);
    include('mysql-close.php');
    header('Location:accList.php');
?>