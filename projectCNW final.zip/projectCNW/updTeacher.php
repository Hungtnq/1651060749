<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('mng-nav.php'); ?> 
                    </div>
                    <div class="col-9 info">
                    <h4>Sửa thông tin giảng viên</h4>
                    <?php
                        $link =  "updTeacher.php?gv=".$_GET['gv'];
                        echo"<form action=".$link." method='post'>"; 
                    ?>
                        <label class="col-3" for="">Tên giảng viên</label>
                        <input class="col-5" type="text" name="tengv" id="">
                        <br>
                        <label class="col-3" for="">Ngành</label>
                        <?php 
                            include('mysql-connect.php');
                            echo"<select name='ng' id='' required>";
                            echo"<option value=''></option>";
                            $sql_ng = "select tenNg from nganh";
                            $result_ng = mysqli_query($conn,$sql_ng);
                            while($row_ng = mysqli_fetch_assoc($result_ng)){
                                echo"<option value='".$row_ng['tenNg']."'>".$row_ng['tenNg']."</option>";
                            }
                            echo"</select>";
                            include('mysql-close.php');
                        ?>
                        <br>
                        <br>
                        <div class="row">
                            <div class="col-3"></div>
                            <input type="submit" value="Sửa">
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>

<?php 
    if(!empty($_POST)){
        include('mysql-connect.php');
        $sql = "update giangvien set giangvien.tengv = ".$_POST['tengv'].", giangvien.maNg = nganh.maNg from giangvien,nganh where giangvien.maNg = nganh.maNg and nganh.tenNg = ".$_POST['tenNg'];
        mysqli_query($conn,$sql);
        include('mysql-close.php');
    }
?>