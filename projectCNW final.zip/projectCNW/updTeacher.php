<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('mng-nav.php'); ?> 
                    </div>
                    <div class="col-9 info">
                    <h4>Sửa thông tin giảng viên</h4>
                    <form action="">
                        <label class="col-3" for="">Tên giảng viên</label>
                        <input class="col-5" type="text" name="" id="">
                        <br>
                        <label class="col-3" for="">Ngành</label>
                        <select name="" id="">
                            <option value=""></option>
                            <option value=""></option>
                            <option value=""></option>
                        </select>
                        <br>
                    </form>
                    <?php 
                        if(!empty($_GET)){
                            $gv = $_GET['gv'];
                        }
                    ?>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>