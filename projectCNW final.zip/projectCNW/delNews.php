<?php 
    include('mysql-connect.php');
    $sql = "delete from baiviet where mabv = ".$_GET['bv'];
    mysqli_query($conn,$sql);
    include('mysql-close.php');
    header('location:newsList.php');
?>