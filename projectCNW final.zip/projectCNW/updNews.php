<header>
            <?php include('header.php'); ?>
            <style>
                .login{
                    display:none;
                }
                .welcome, .logout{
                    display:inline;
                }
            </style>
        </header>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-3 vert-nav">
                        <?php include('admin-nav.php'); ?>
                    </div>
                    <div class="col-9 info">
                    <h4>Sửa bài viết: </h4>
                    <?php 
                        include('mysql-connect.php');
                        $sql = "select * from baiviet where mabv=".$_GET['bv'];
                        $result = mysqli_query($conn,$sql);
                        if($result){
                            if(mysqli_num_rows($result) == 1){
                                $row = mysqli_fetch_assoc($result);
                            }
                        }
                        echo"<form action=''>";
                        echo"<div class='row'>";
                        echo"<label class='col-2' for=''>Tiêu đề</label>";
                        echo"<input type='text' name='' class='col-5' id='' value=".$row['tieude'].">";
                        echo"</div>";
                        echo"<br>";
                        echo"<div class='row'>";
                        ?>
                        <label class='col-2' for=''>Tóm tắt</label>
                        <textarea name='' id='' cols='60' rows='5' ><?php echo $row['tomtat'] ?></textarea>
                        </div>
                        <br>
                        <div class='row'>
                        <label class='col-2' for=''>Nội dung</label>
                        <textarea name='' id='' cols='60' rows='10'><?php echo $row['noidung'] ?></textarea>
                        </div>
                        <br>
                        <?php
                        echo"<label class='col-2' for=''>Tác giả</label>";
                        echo"<select name='tg' id=''>";
                                echo"<option value=''></option>";
                                $sql_tg = "select maqt,tenqt from quantri";
                                $result_tg = mysqli_query($conn,$sql_tg);
                                while($row_tg = mysqli_fetch_assoc($result_tg)){
                                    echo"<option value='".$row_tg['maqt']."'>".$row_tg['tenqt']."</option>";
                                }
                                echo"</select>";
                        echo"<br><br>";
                        echo"<div class='row'>";
                        echo"<div class='col-2'></div>";
                        echo"<input type='submit' value='Sửa bài viết'>";
                        echo"</div>";
                        echo"</form>";
                        include('mysql-close.php');
                    ?>
                        
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>
