        <header>
            <?php include('header.php'); ?> 
        </header>
        <main>
            <form class="r-search" action="">
                <label for="">Mã sinh viên</label>
                <input type="text" name="msv" id="">
                <label for="">Số CMTND</label>
                <input type="text" name="cmtnd" id="">
                <label for="">Môn học</label>
                <input type="text" name="mon" id="">
                <br>
                <label for="">Năm học</label>
                <select name="nam" id="">
                    <option value="2018-2019">2018-2019</option>
                    <option value="2018-2019">2018-2019</option>
                    <option value="2018-2019">2018-2019</option>
                    <option value="2018-2019">2018-2019</option>
                </select>
                <label for="">Kỳ</label>
                <select name="nam" id="">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="song song">song song</option>
                </select>
                <label for="">Giai đoạn</label>
                <select name="nam" id="">
                    <option value="1">1</option>
                    <option value="2">2</option>
                </select>
            </form>
        </main>
        <footer>
            <?php include('footer.php'); ?> 
        </footer>
    </body>
</html>